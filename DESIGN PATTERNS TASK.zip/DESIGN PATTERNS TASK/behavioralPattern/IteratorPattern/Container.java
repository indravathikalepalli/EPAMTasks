package behavioralPattern.IteratorPattern;

public interface Container 
{
	public Iterator getIterator(); 
}
